import { Filter } from "./components/filter";
import { NullCheck } from "./components/null-check-operator";
import { ArrowFunction } from "./components/arrow-function";
import App from "./views/home";
import { Button } from "./components/button";

export default function MainApp() {
  // const deleteItem = () => {
  //   alert('deleted')
  // }

  // const updateItem = () => {
  //   alert('updated')
  // }
  return (
    <>
      {/* <App />
      <NullCheck />
      <Filter />
      <ArrowFunction /> */}

      {/* <Button btnText={"Sil"} variant="primary" onClick={deleteItem} />

      <Button btnText={"Güncelle"} variant="secondary" onClick={updateItem}  /> */}
    </>
  );
}

// function Button(text) {

// }

// Button('Kaydet')
