const App3 = () => {
  return <div>Merhaba Dünya </div>;
};

export {  App3 };
