export default function App() {
  return <div>Ana Komponent</div>;
}

