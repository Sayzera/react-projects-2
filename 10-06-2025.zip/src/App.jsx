import Comments from "./views/comments";

export default function MainApp() {
  // Cart içersinde tıklanabilme özelliği kazandıralım
  return (
    <Comments />
  );
}
