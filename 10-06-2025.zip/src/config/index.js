

export const projectConfig = {
    nullCheckTestMode: false

}