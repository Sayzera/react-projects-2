

const projectColors = {
    btnPrimaryColor: 'pink',
    btnSecondaryColor: 'gray'
}

export {
    projectColors
}